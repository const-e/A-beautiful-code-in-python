# A-beautiful-code-in-Python
Eine launige Einführung in Python

Die Serie dient Anfängern zum Erlenen der Sprache. Anhand von Aufgaben werden Python-Befehle eingeführt und erläutert.

Zu jedem Programm gibt es ein Video auf YouTube

https://www.youtube.com/watch?v=C8R5zt7TIVU&list=PLhC_4AWNg9rnM_qAPyUU4Wo1kJoOAMC6_

Im Zweifel werden die Videos dann relativ lang, da ich die Befehle und die hinter dem Algorithmus liegenden Gedanken ziemlich ausführlich erläutere.

Nach Möglichkeit, versuche ich dabei, möglichst leicht lesbaren = pythonic Code zu erzeugen.

Nebenbei bemerkt, lerne ich dadurch auch noch einen ganze Menge dazu, denn nichts ist besser zum Lernen von neuen Inhalten geeignet, als das Erklären des Gelernten an einen Dritten :-)

Falls Ihr Optimierungsmöglichkeiten entdeckt, immer gen hier unter "Issues" hinterlegen.

Viel Spass bei den Beispielen wünscht

GRAVITAR
